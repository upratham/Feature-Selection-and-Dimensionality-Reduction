to run whole project 
- python src/model_eval.py 

